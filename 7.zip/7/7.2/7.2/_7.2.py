mystring=str(input())

err=' '.join(mystring.split())

print(err)
