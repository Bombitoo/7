slovo = str(input())

a = slovo[::-1]

if slovo == a:

print("yes")

else:

print("no")
